SERVER_HOST = '127.0.0.1'
SERVER_PORT = 5000
NICKNAME = input("Enter your nickname: ")
